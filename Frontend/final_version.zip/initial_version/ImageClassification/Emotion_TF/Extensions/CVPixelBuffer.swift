//
//  CVPixelBuffer.swift
//  ASMR
//
//  Created by Li Cheuk Yin on 20/1/2021.
//  Copyright © 2021 Li Cheuk Yin. All rights reserved.
//
import Foundation
import UIKit
import Accelerate

extension CVPixelBuffer {


  func centerThumbnail(ofSize size: CGSize ) -> CVPixelBuffer? {

    assert(CVPixelBufferGetPixelFormatType(self) == kCVPixelFormatType_32BGRA)

    let thumbnailSize = min(CVPixelBufferGetWidth(self),CVPixelBufferGetHeight(self))
    CVPixelBufferLockBaseAddress(self, CVPixelBufferLockFlags(rawValue: 0))

    var getX = 0
    var getY = 0

    if CVPixelBufferGetWidth(self) > CVPixelBufferGetHeight(self) {
        getX = (CVPixelBufferGetWidth(self) - CVPixelBufferGetHeight(self)) / 2
    }
    else {
        getY = (CVPixelBufferGetHeight(self) - CVPixelBufferGetWidth(self)) / 2
    }
    guard let inputBaseAddress = CVPixelBufferGetBaseAddress(self)?.advanced(
        by: getY * CVPixelBufferGetBytesPerRow(self) + getX * 4) else {
      return nil
    }

    var inputVImageBuffer = vImage_Buffer(data: inputBaseAddress, height: UInt(thumbnailSize), width: UInt(thumbnailSize),rowBytes: CVPixelBufferGetBytesPerRow(self))

    let thumbnailRowBytes = Int(size.width) * 4
    guard  let thumbnailBytes = malloc(Int(size.height) * thumbnailRowBytes) else {
      return nil
    }

    var thumbnailVImageBuffer = vImage_Buffer(data: thumbnailBytes, height: UInt(size.height), width: UInt(size.width), rowBytes: thumbnailRowBytes)

    let scaleError = vImageScale_ARGB8888(&inputVImageBuffer, &thumbnailVImageBuffer, nil, vImage_Flags(0))

    CVPixelBufferUnlockBaseAddress(self, CVPixelBufferLockFlags(rawValue: 0))

    guard scaleError == kvImageNoError else {
      return nil
    }

    let releaseCallBack: CVPixelBufferReleaseBytesCallback = {mutablePointer, pointer in

      if let pointer = pointer {
        free(UnsafeMutableRawPointer(mutating: pointer))
      }
    }

    var thumbnailPixelBuffer: CVPixelBuffer?

    let conversionStatus = CVPixelBufferCreateWithBytes(
        nil, Int(size.width), Int(size.height), CVPixelBufferGetPixelFormatType(self), thumbnailBytes,
        thumbnailRowBytes, releaseCallBack, nil, nil, &thumbnailPixelBuffer)

    guard conversionStatus == kCVReturnSuccess else {

      free(thumbnailBytes)
      return nil
    }

    return thumbnailPixelBuffer
  }

  static func buffer(from image: UIImage) -> CVPixelBuffer? {
    let attrs = [
      kCVPixelBufferCGImageCompatibilityKey: kCFBooleanTrue,
      kCVPixelBufferCGBitmapContextCompatibilityKey: kCFBooleanTrue
    ] as CFDictionary

    var pixelBuffer: CVPixelBuffer?
    let status = CVPixelBufferCreate(kCFAllocatorDefault,Int(image.size.width),Int(image.size.height),kCVPixelFormatType_32BGRA,attrs,&pixelBuffer)

    guard let buffer = pixelBuffer, status == kCVReturnSuccess else {
      return nil
    }

    CVPixelBufferLockBaseAddress(buffer, [])
    defer { CVPixelBufferUnlockBaseAddress(buffer, []) }
    let pixelData = CVPixelBufferGetBaseAddress(buffer)

    let rgbColorSpace = CGColorSpaceCreateDeviceRGB()
    guard let context = CGContext(data: pixelData,width: Int(image.size.width),height: Int(image.size.height),bitsPerComponent: 8,bytesPerRow: CVPixelBufferGetBytesPerRow(buffer),space: rgbColorSpace,bitmapInfo: CGImageAlphaInfo.noneSkipLast.rawValue) else {
      return nil
    }

    context.translateBy(x: 0, y: image.size.height)
    context.scaleBy(x: 1.0, y: -1.0)

    UIGraphicsPushContext(context)
    image.draw(in: CGRect(x: 0, y: 0, width: image.size.width, height: image.size.height))
    UIGraphicsPopContext()

    return pixelBuffer
  }

}
